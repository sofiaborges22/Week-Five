

$(function(){
	var pokedex = new window.Pokeapp.Pokedex();
	pokedex.start();
})