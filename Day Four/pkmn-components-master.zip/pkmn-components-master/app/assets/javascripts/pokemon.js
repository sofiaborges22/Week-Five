// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
(function () {
	var Pokemon = function(attrs){
		this.name = attrs.name;
		this.height = attrs.height;
		this.weight = attrs.weight;
		this.nationalId = attrs.national_id;
	}	
	if (typeof window.Pokeapp === 'undefined') {
		window.Pokeapp = {};
	}
	window.Pokeapp.Pokemon = Pokemon;
})();