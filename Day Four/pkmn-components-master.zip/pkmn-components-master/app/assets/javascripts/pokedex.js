(function () {
	var Pokedex = function() {};

	Pokedex.prototype.start = function () {
		$('.js-show-pokemon').on('click', function(event) {
			var clickedEl = $(event.currentTarget)
			var path = clickedEl.attr('data-pokemon-uri');
			$.ajax({
				type: 'GET',
				url: path,
				success: function(attrs) {
					var pokemon = new window.Pokeapp.Pokemon(attrs);
					$('#name').text(pokemon.name);
					$('#height').text(pokemon.height);
					$('#weight').text(pokemon.weight);
					$('#national_id').text('#' + pokemon.nationalId);
					$('.modal').modal('show')
				},
				error: function(err) {
					console.log("error");
					console.log(err);
				}
			})
		});	
	}	
	if (typeof window.Pokeapp === 'undefined') {
		window.Pokeapp = {};
	}
	window.Pokeapp.Pokedex = Pokedex;
})();